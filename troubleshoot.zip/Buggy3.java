// 1. What output will you get?
// 2. What do you think was intended?
// 3. What would be a suitable approach to debugging?
// 4. How would you rewrite the code?

// Scroll down for answers.

public class Buggy3 {
	public static void main(String[] args) {
		int score = 4000;
		Placement p = new Placement();
		checkStatus(score, p);
		System.out.println(p.getStatus());
	}
	static void checkStatus(int score, Placement placement) {
		if(score > 4000) {
			placement.setStatus("Upper half");
		}
		if(score <= 3999) {
			placement.setStatus("Lower half");
		}
	}
}

class Placement {
	private String status;
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return this.status;
	}
}

// 1. null - because the value of p.status is never set. This is
// because the two if statements do not take into account a value
// of 4000 for score.
// 2. Most likely "Upper half" but this is an assumption that you
// should check.
// 3. Put "At line n" print statements inside the blocks for the
// two if statements to see if they are reached. Put "In
// checkStatus" print statement after line 15 which also prints
// the values of score and placement. (placement should consist
// of the class name, an @ symbol and some hex numbers.)
// 4. Again, based on the assumption, replace the two if
// statements with a single if else so the value of score is only
// checked once.