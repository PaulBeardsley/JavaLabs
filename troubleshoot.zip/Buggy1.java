// 1. What output will you get with the present code?
// 2. Why are the other methods NOT called?
// 3. If you add a name to the names array, do you need to make
//    any other changes?

// Scroll down for answers.

public class Buggy1 {
	public static void main(String[] args) {
		int i;
		String[] names = {"Sam", "Chris", "Becky"};
		
		for(i=0; i<names.length; i++) {
			System.out.println(names[i]);
		}
		switch(i) {
			case 2: two();
				break;
			case 3: three();
				break;
			case 4: four();
				break;
			default: other();
		}
	}
	static void two() {
		System.out.println("i is 2");
	}
	static void three() {
		System.out.println("i is 3");
	}
	static void four() {
		System.out.println("i is 4");
	}
	static void other() {
		System.out.println("i cannot be accessed outside for loop");
	}
}

// 1. The three names are printed, followed by i is 3.
// 2. other() is not called because i is declared before the
// for loop; it is then initialised inside the for loop but
// remains visible outside the loop.
// If i was declared inside the for loop, it would not be
// visible outside the loop, and so the code would not compile.
// During the last iteration of the loop, i is 2. At the end
// of this iteration, i is incremented once more, making it 3,
// which is the length of the array. The condition 3<3 is false // so the loop exits.
// So three() is called rather than two() or four().
// 3. No other change need be made as names.length takes care of
// the actual number of elements. i will have the value 4 when
// the loop exits and so four() will be called.
