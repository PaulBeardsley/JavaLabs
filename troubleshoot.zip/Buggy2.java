// 1. Which, if any, of the commented out lines can be restored
// without causing a compilation error?
// 2. What output do you expect from the present code?
// 3. Which other values can be printed without causing a
// compilation failure?

// Scroll down for answers.

public class Buggy2 {
	public static void main(String[] args) {
		Store sA;
		Store sB = new Store();
		Store sC = new Store();
		
		//sA.ival = 1;
		//sA.sval = 20;
		sB.ival = 2;
		sC.ival = 3;
		
		sA = sB;
		sB.sval = 30;
		sC.sval = 50;
		sB = null;
		
		System.out.println(sA.ival);
		System.out.println(sA.sval);
	}
}
		
class Store {
	int ival;
	static int sval;
}

// 1. Neither, even though sval belongs to the class rather than
// the object.
// 2. 2 and 50
// 3. sC.ival, sc.sval, and Store.sval.
// Note that on line 20, it is the reference being copied from sB
// to sA, not the actual object. The command on line 23 simply
// means that sB no longer points to anything; it does not mean
// the object is destroyed, and so the value stored in sA is not
// affected.