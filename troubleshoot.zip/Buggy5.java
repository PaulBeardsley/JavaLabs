// 1. What output will you get?
// 2. What do you think was intended?
// 3. Why is one of the values not the intended one?
// 4. How would you rewrite the code?

// Scroll down for answers.

public class Buggy5 {
	public static void main(String[] args) {
		Person p = new Person("Douglas", 42);
		System.out.println(p.getFirstName());
		System.out.println(p.getAge());
	}
}

class Person {
	private int age;
	private String firstName;
	
	Person(String fname, int age) {
		firstName = fname;
		age = age;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public int getAge() {
		return age;
	}
}

// 1. The output is the String "Douglas" followed by the int 0.
// 2. The String is as intended but the intended age value was
// 42 rather than 0.
// 3. On line 22, the value of the parameter age is simply being 
// copied back into itself. This is not a problem for the String,
// because the name of the parameter is not the same as the name
// of the instance variable.
// 4. Put this. in front of the instance variables in all cases,
// i.e. lines 21, 22, 26 and 29. In particular, line 22 should
// read
// this.age = age;