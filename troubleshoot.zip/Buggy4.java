// 1. What output will you get?
// 2. Is this the intended output?
// 3. What if you changed age to 12? To 60?
// 4. How would you rewrite the code?

// Scroll down for answers.

public class Buggy4 {
	public static void main(String[] args) {
		int age = 25; // This would be a user input
		if((age >= 18) || (age <= 30)) {
			System.out.println("You can go on an 18-30 holiday.");
		}
		else {
			System.out.println("Sorry, you are not eligible.");
		}
	}
}

// 1. "You can go on an 18-30 holiday."
// 2. Yes, but...
// 3. You get the same output, even though you should not be
// eligible for an 18-30 holiday if you are 12 or 60!
// The problem is in the logic. 25 >= 18 returns true, but so
// does 60 >= 18. Likewise, 25 <= 30 returns true, but so does
// 12 <= 30.
// In fact there is no value of age that does NOT return true
// in the condition on line 11.
// 4. Simply replace the || on line 11 with &&. That way you
// have to be 18 or over AND 30 or under to be eligible.